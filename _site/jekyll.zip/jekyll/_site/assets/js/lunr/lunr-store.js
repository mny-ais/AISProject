var store = [{
        "title": "Edge Case: Nested and Mixed Lists",
        "excerpt":"Nested and mixed lists are an interesting beast. It’s a corner case to make sure that Lists within lists do not break the ordered list numbering order Your list styles go deep enough. Ordered – Unordered – Ordered ordered item ordered item unordered unordered ordered item ordered item ordered item...","categories": ["Edge Case"],
        "tags": ["content","css","edge case","lists","markup"],
        "url": "http://localhost:4000/edge%20case/edge-case-nested-and-mixed-lists/",
        "teaser":"http://localhost:4000/assets/images/AD.png"},{
        "title": "Welcome to Jekylllllllll!",
        "excerpt":"You’ll find this post in your _posts directory. Go ahead and edit it and re-build the site to see your changes. You can rebuild the site in many different ways, but the most common way is to run jekyll serve, which launches a web server and auto-regenerates your site when...","categories": ["jekyll","update"],
        "tags": [],
        "url": "http://localhost:4000/jekyll/update/test/",
        "teaser":"http://localhost:4000/assets/images/AD.png"},{
        "title": "Welcome to Jekyll!",
        "excerpt":"You’ll find this post in your _posts directory. Go ahead and edit it and re-build the site to see your changes. You can rebuild the site in many different ways, but the most common way is to run jekyll serve, which launches a web server and auto-regenerates your site when...","categories": ["jekyll","update"],
        "tags": [],
        "url": "http://localhost:4000/jekyll/update/welcome-to-jekyll/",
        "teaser":"http://localhost:4000/assets/images/AD.png"},{
        "title": "MNYs Deep Learning Self Driving Car",
        "excerpt":"Some Context This is our bachelor project at the Chair for Autonomous Intelligent Systems (AIS) at the University of Freiburg. It was on a self-driving car based on the paper “End-to-End Driving via Conditional Imitation Learning” by Codevilla et al. Here we implement the architecture given in the paper and...","categories": ["Self Driving Car","Deep Learning","Neural Network","Maximilian Christian Roth","Nina Claire Pant","Yvan Putra Satyawan"],
        "tags": ["content","css","markup"],
        "url": "http://localhost:4000/self%20driving%20car/deep%20learning/neural%20network/maximilian%20christian%20roth/nina%20claire%20pant/yvan%20putra%20satyawan/first-post/",
        "teaser":"http://localhost:4000/assets/images/AD.png"}]
